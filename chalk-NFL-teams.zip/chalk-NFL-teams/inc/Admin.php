<?php
/**
*@package ChalkNFLPlugin
*/

namespace Inc;

class Admin {

    function build_page() {
    
        echo '<h1>Chalk NFL Teams Plugin</h1>';

        echo '<p>To display the NFL table in any post or page of your Wordpress site, simply input the shortcode <code>[chalkNFLteams]</code> in the desired location.</p>';

    }
}